%%% convex variational model of multiplicative noise cleaning, implemented by Xi-Le Zhao(UESTC & HKBU)
function out = CMC3(Bn,I,N,mvw,alpha,opts)
beta = opts.beta;

[m n] = size(Bn);
varw=sum(sum((1./N-mvw).^2))/m/n;
T=m*n;%%total number
[D,Dt] = defDDt;
eigsH = ones(m,n);%psf2otf(H,[m,n])/beta;
eigsHTH=ones(m,n);%abs(psf2otf(H,[m,n])).^2;
eigsDTD=abs(psf2otf([1,-1],[m n])).^2 + abs(psf2otf([1;-1],[m n])).^2;
a=(1+1/beta)*ones(m,n);
b=-conj(eigsH)/beta;
c=-eigsH/beta;
d=(1/beta)*eigsHTH+eigsDTD+ones(m,n);
S=1./(Bn.^2+2*ones(m,n));
% initialization
Lam1 = zeros(2*m,n);
Lam2 = zeros(m,n);
Lam3 = zeros(m,n);
Lam4 = zeros(m,n);
Lam5 = zeros(m,n);
Lam6 = 0;
% initialization y=[w; p; q]
f=Bn;
[D1X,D2X] = D(Bn);
 p(1:m,:)=D1X;
 p(m+1:2*m,:)=D2X;
 q=Bn;
 w=zeros(m,n);
 u=zeros(m,n);
%  history
out.psnr = [];
out.relf=[];
out.reln=[];
out.fval=[];
out.relchg = [];
out.relchgw = [];
relchg=1;
ii=1;
%% Main loop
while relchg > opts.relchg && ii<opts.maxitr
    %%%% Step 1 update x=[f;s;u;v]
    % ==================
    %  [f; s] subproblem
    % ==================
    fp=f;
    e=fft2(Bn.*w-Lam3/beta);
    g=fft2(Dt(p(1:m,:),p(m+1:2*m,:))-Dt(Lam1(1:m,:),Lam1(m+1:2*m,:))/beta+q-Lam2/beta);
    %%%solve the ax+cy=e, bx+dy=g linear system by Cramer's Rule
    Det=a.*d-b.*c;
    s=(e.*d-g.*c)./Det;
    f=(a.*g-b.*e)./Det;
    s=real(ifft2(s));
    f=real(ifft2(f));
    [D1X,D2X] = D(f);
    % ==================
    %  u subproblem
    % ==================
    up=u;
    scale=max(norm(Lam4/beta+mvw*ones(m,n)-w,'fro')-sqrt(T*varw),0)/norm(Lam4/beta+mvw*ones(m,n)-w,'fro');
    u=scale*(Lam4/beta+mvw*ones(m,n)-w)+w-Lam4/beta;
    % ==================
    %  v subproblem
    % ==================
    v=max(w-Lam5/beta,0);   
    %%%% Step 2 update [w; p; q]
    % ==================
    %  w subproblem
    % ==================
    wp=w;
    right=Bn.*(s+Lam3/beta)+u+Lam4/beta+v+Lam5/beta+(mvw/T-Lam6/beta/T)*ones(m,n);
    w=S.*right-S.*sum(sum(S.*right))*ones(m,n)/T^2/(1+sum(S(:))/T^2);
    % ==================
    %  p subproblem
    % ==================
    Z1 = D1X + Lam1(1:m,:)/beta;
    Z2 = D2X + Lam1(m+1:2*m,:)/beta;
    V = Z1.^2 + Z2.^2;
    V = sqrt(V);
    V(V==0) = 1;
    V = max(V - alpha/beta, 0)./V;
    p(1:m,:) = Z1.*V;
    p(m+1:2*m,:) = Z2.*V;
    % ==================
    %  q subprolem
    % ==================
    q= max(f+Lam2/beta,0);
    %%%%metric
    psnrf= psnr(f,I);
    out.psnr = [out.psnr; psnrf];
    relchg = norm(f - fp,'fro')/norm(f,'fro');
    out.relchg = [out.relchg; relchg];
    relchgw= norm(w - wp,'fro')/norm(w,'fro');
    out.relchgw=[out.relchgw,relchgw];
    relf=norm(f- I,'fro')/norm(I,'fro'); %relative error wrt true image
    reln=norm(1./w-N,'fro')/norm(N,'fro');%relative error wrt true noise
    out.relf=[out.relf,relf];
    out.reln=[out.reln,reln];
    fval=0.5*norm(Bn.*w-f,'fro')+alpha*sum(sum(sqrt(D1X.^2 + D2X.^2)));
    out.fval=[out.fval,fval];
    ii=ii+1;
    % ==================
    %    Update Lam
    % ==================   
    Lam1(1:m,:) = Lam1(1:m,:) + beta*(D1X-p(1:m,:));
    Lam1(m+1:2*m,:) = Lam1(m+1:2*m,:) + beta*(D2X-p(m+1:2*m,:));
    Lam2 = Lam2 + beta*(f-q);
    Lam3 = Lam3 + beta*(s-Bn.*w);
    Lam4 = Lam4 + beta*(u-w);
    Lam5 = Lam5 + beta*(v-w);
    Lam6= Lam6+beta*(sum(w(:))/T-mvw);
end
out.sol = f;
out.w=w;
out.itr = ii;
fprintf('Iter: %d, psnrf: %4.2f, relf: %4.2f,reln: %4.2f\n',ii,psnrf,relf,reln);
mv=sum(w(:))/m/n;
var=sum((w(:)-mv).^2)/m/n;
fprintf('mv: %4.2f, var: %4.2f, mvw: %4.2f, varw: %4.2f\n',mv,var,mvw,varw);
