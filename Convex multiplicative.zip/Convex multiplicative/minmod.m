function m = minmod(a,b)
m = sign(a) + sign(b);
m = m.*min(abs(a),abs(b))/2;