% 
clear all
close all
I=imread('cameraman.tif');
I=double(I);
[m,n]=size(I); 
% 
% 
% % Add noise  with the mean 1
% % Gamma noise
% % L=6;%%Look
% % N= gamrnd(L,1/L,m, n);
% % Gaussian noise
% N=1+0.3*randn(m,n);
% % Rayleigh noise
N=rand(m,n);
%%sigma=1
N=5*sqrt(-2*log(1-N));
%%caculate the mean of w
mvw=sum(sum(1./N))/m/n;
% 
 Bn=I.*N;


opts.maxitr=3500;
% for i=2:4
%     for j=2:4
%         for k=2:4
opts.beta =10^(-6);
alpha1=10^(-5);
alpha2=10^(-5);
t3=cputime;out3=CMC1(Bn,I,N,mvw, alpha1, alpha2,opts);t3=cputime-t3;
fprintf('psnr: %2.4f, iteration: %4f, time: %4.4f\n',out3.psnr(end),out3.itr,t3);
out3.sol(out3.sol>255)=255;figure,imshow(out3.sol,[])
% 
% % t1=cputime;out1= AA(Bn,I,alpha,3000);t1=cputime-t1;
% % fprintf('psnr: %2.4f, iteration: %4f, time: %4.4f\n',out1.psnr(end),out1.itr,t1);
% out1.sol(out1.sol>255)=255;figure,imshow(out1.sol,[])

%  
%  
% opts.nitr=3;opts.beta=100;t2=cputime;out2= ADM(Bn,I,0.5,opts);t2=cputime-t2;
% % fprintf('psnr: %2.4f, iteration: %4f, time: %4.4f\n',out2.psnr(end),out2.itr,t2);
% out2.sol(out2.sol>255)=255;figure,imshow(out2.sol,[])
%          end
%      end
%  end



