%%%%Newton's method
function Z = newton(Z,Gn,Lam3,U,beta,initer)
for i=1:initer 
  Dz=(ones(size(Z))-exp(Gn-Z)+beta*(Z-U-Lam3/beta))./(exp(Gn-Z)+beta*ones(size(Z)));
  Z=Z-Dz;
end