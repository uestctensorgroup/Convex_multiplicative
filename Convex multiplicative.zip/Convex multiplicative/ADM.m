%%%Ref: Bioucas-Dias, Multiplicative noise removal using variable splitting and
%%%constrained optimizaiton, IEEE TIP, 2010, implemented by Xi-Le Zhao(UESTC & HKBU)
function out = ADM(Bn,I,alpha,opts)
% Suppose the data accuquisition model is given by: log(Bn)= log(I) + log(Noise),
% where I is an original image, Noise is
% Gamma noise, and Bn is a blurry and noisy observation. To recover
% I from Bn, we solve the following model
% ***     min_z \sum_i(z+exp(Bn-z))+mu\sum_i ||Di*z||       ***
% Inputs:
%         Bn ---  blurry and noisy observation
%         mu ---  regularization prameter 
%         opts --- a structure containing algorithm parameters {default}
%                 * opst.beta    : a positive constant {10}
%                 * opst.gamma   : a constant in (0,1.618] {1.618}
%                 * opst.maxitr  : maximum iteration number {500}
%                 * opst.relchg  : a small positive parameter.
% Outputs:
%         out --- a structure contains the following fields
%                * out.psnr   : SNR values at each iteration
%                * out.relchg: the history of relative change in X
%                * out.sol   : numerical solution obtained by this code
%                * out.itr   : number of iterations used
%%% Natural logarithm transform 
Gn=log(Bn);
[m n] = size(Bn);
[D,Dt] = defDDt;
% initialization
Lam1 = zeros(m,n);
Lam2 = zeros(m,n);
Lam3 = zeros(m,n);
U=Gn;
Z=ones(m,n);
beta =opts.beta;
nitr =opts.nitr;
out.psnr = [];
out.relchg = [];
out.rel=[];
fvalchg=1;
out.fvalchg=[];
ii=0;
relchg=1;
fval=1;
out.fval=[];
 [D1X,D2X] = D(Gn);
%% Main loop
while fvalchg> 5*10^(-4) && ii<opts.maxitr
    % ==================
    %  W subproblem 
    % ==================
    Z1 = D1X + Lam1/beta;
    Z2 = D2X + Lam2/beta;
    V = Z1.^2 + Z2.^2;
    V = sqrt(V);
    V(V==0) = 1;
    V = max(V - alpha/beta, 0)./V;
    W1 = Z1.*V;
    W2 = Z2.*V;   
    % ==================
    %  Z subprolem
    % ==================
    Z= newton(Z,Gn,Lam3,U,beta,nitr); 
    % ==================
    %  U subprolem
    % ==================
    Up=U;
    U = Dt(W1,W2)-Dt(Lam1,Lam2)/beta+Z-Lam3/beta;
    U = fft2(U)./(abs(psf2otf([1,-1],[m n])).^2 + abs(psf2otf([1;-1],[m n])).^2 + ones(m,n));
    U = real(ifft2(U));
    [D1X,D2X] = D(U);
    psnrU= psnr(exp(U),I);
    out.psnr = [out.psnr; psnrU];
    relchg = norm(exp(U) - exp(Up),'fro')/norm(exp(U),'fro');
    out.relchg = [out.relchg; relchg];
    out.rel=[out.rel,norm(I-exp(U),'fro')/norm(I,'fro')];
   fval_old=fval;
    fval=sum(Z(:))+sum(exp(Gn(:)-Z(:)))+alpha*sum(sum(sqrt(D1X.^2 + D2X.^2)));
       fvalchg=abs(fval-fval_old)/abs(fval);
    out.fvalchg=[out.fvalchg,fvalchg];
    out.fval=[out.fval,fval];
    % ==================
    %    Update Lam
    % ==================   
    Lam1 = Lam1 + beta*(D1X-W1);
    Lam2 = Lam2 + beta*(D2X-W2);  
    Lam3 = Lam3 + beta*(U-Z);
    ii=ii+1;
end
out.sol = exp(U);
out.itr = ii;
%% nested functions
    function [D,Dt] = defDDt
        % defines finite difference operator D
        % and its transpose operator      
        D = @(U) ForwardD(U);
        Dt = @(X,Y) Dive(X,Y);       
        function [Dux,Duy] = ForwardD(U)
            % Forward finite difference operator
            Dux = [diff(U,1,2), U(:,1) - U(:,end)];
            Duy = [diff(U,1,1); U(1,:) - U(end,:)];
        end   
        function DtXY = Dive(X,Y)
            % Transpose of the forward finite difference operator
            DtXY = [X(:,end) - X(:, 1), -diff(X,1,2)];
            DtXY = DtXY + [Y(end,:) - Y(1, :); -diff(Y,1,1)];
        end
    end
end