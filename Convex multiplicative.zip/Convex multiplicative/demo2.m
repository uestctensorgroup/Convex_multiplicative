%%%%deblurring
clear all
I=imread('cameraman.tif');
I=double(I);
[m,n]=size(I); %M:y, N:x
opts.relchg = 1.e-4;
% Add gamma noise   the expected value of gamma noise is 1,
% the variance of gamma noise is 1/L
L =10;%%Look
N= gamrnd(L,1/L,m, n);
H = fspecial('gaussian',5,2);
Bn = imfilter(I,H,'circular','conv');
mvw=sum(sum(1./N))/m/n;
Bn=Bn.*N;
for i=-3:3
    for j=-3:3
        for k=-3:3
            opts.maxitr=3000;
            opts.beta=10^(i);
            alpha1=10^(j);
            alpha2=10^(k);
            out1D = CMC1D(Bn,I,N,H,mvw,alpha1,alpha2,opts);
           fprintf('beta: %1.4f, a1: %1.4f, a2: %1.4f\n',opts.beta, alpha1, alpha2)
        end
    end
end