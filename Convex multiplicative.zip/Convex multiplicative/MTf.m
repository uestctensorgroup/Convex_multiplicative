function out = MTf(I,eigsH) 
out=real(ifft2(conj(eigsH).* fft2(I)));