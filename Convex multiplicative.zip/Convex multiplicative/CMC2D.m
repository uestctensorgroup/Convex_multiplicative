%%% convex variational model of multiplicative noise cleaning, implemented by Xi-Le Zhao(UESTC & HKBU)
function out = CMC2D(Bn,I,H,N,mn,alpha,opts)
% Suppose the data accuquisition model is given by: Bn= I.*Noise,
% where I is an original image, Noise is
% Gamma noise, and Bn is a noisy observation. To recover
% I from Bn, we solve the following model
% ***    arg min_{f,w} 1/2||w-mn||_2^2+alpha\sum_i ||Di*f||       ***
% ***    st:  f=Bn.*w where w=1./Noise.
% Inputs:
%         Bn ---   noisy observation
%         alpha--- regularization prameter
%         opts --- a structure containing algorithm parameters {default}
%                 * opst.beta    : a positive constant {10}
%                 * opst.maxitr  : maximum iteration number {500}
%                 * opst.relchg  : a small positive parameter.
% Outputs:
%         out --- a structure contains the following fields
%                * out.snr   : SNR values at each iteration
%                * out.relchg: the history of relative change in f
%                * out.sol   : numerical solution
%                * out.itr   : number of iterations used
beta = opts.beta;
[m n] = size(Bn);


[D,Dt] = defDDt;
eigsDTD=abs(psf2otf([1,-1],[m n])).^2 + abs(psf2otf([1;-1],[m n])).^2;
eigsH = psf2otf(H,[m,n]);
eigsHTH = abs(eigsH).^2;
% initialization
Lam1 = zeros(2*m,n);
Lam2 = zeros(m,n);
Lam3 = zeros(m,n);
Lam4 = zeros(m,n);
% initialization x=[f; v]
f=Bn;
[D1X,D2X] = D(Bn);
v=ones(m,n);
w=ones(m,n);
%history
out.psnr = [];
out.rel1=[];
out.rel2=[];
out.fval=[];
out.relchg = [];
out.relchgw = [];
relchg=1;
ii=1;
%% Main loop
while relchg > opts.relchg && ii<opts.maxitr
    %%%% Step 1 update y=[w;p;q]
    % ==================
    %  w subproblem
    % ==================
    wp=w;
    right1=mn*ones(m,n)+Bn.*(beta*(Mf(f,eigsH))+Lam2)+(beta*v+Lam4);
    w=right1./((1+beta)*ones(m,n)+beta*(Bn.^2));
    % ==================
    %  p subproblem
    % ==================
    Z1 = D1X + Lam1(1:m,:)/beta;
    Z2 = D2X + Lam1(m+1:2*m,:)/beta;
    V = Z1.^2 + Z2.^2;
    V = sqrt(V);
    V(V==0) = 1;
    V = max(V - alpha/beta, 0)./V;
    p(1:m,:) = Z1.*V;
    p(m+1:2*m,:) = Z2.*V;
    % ==================
    %  q subprolem
    % ==================
    q= max(f+Lam3/beta,0);
    q=min(q,255);
    %%%% Step 2 update y=[f;v]
    % ==================
    %  f subprolem
    % ==================
    fp=f;
    f=Dt(p(1:m,:),p(m+1:2*m,:))-Dt(Lam1(1:m,:),Lam1(m+1:2*m,:))/beta+MTf(Bn.*w-Lam2/beta,eigsH)+q-Lam3/beta;
    f=fft2(f);
    f=f./(ones(m,n)+eigsDTD+eigsHTH);
    f=real(ifft2(f));
    [D1X,D2X] = D(f);
    
    % ==================
    %  v subproblem
    % ==================
    v=max(w-Lam4/beta,0);
    %%%%metric
    psnrf= psnr(f,I);
    out.psnr = [out.psnr; psnrf];
    relchg = norm(f - fp,'fro')/norm(f,'fro');
    out.relchg = [out.relchg; relchg];
    relchgw= norm(w - wp,'fro')/norm(w,'fro');
    out.relchgw=[out.relchgw,relchgw];
    rel1=norm(f- I,'fro')/norm(I,'fro'); %relative error wrt true image
    rel2=norm(1./w-N,'fro')/norm(N,'fro');%relative error wrt true noise
    out.rel1=[out.rel1,rel1];
    out.rel2=[out.rel2,rel2];
    fval=0.5*(norm(w-mn*ones(m,n),'fro')).^2+alpha*sum(sum(sqrt(D1X.^2 + D2X.^2)));
    out.fval=[out.fval,fval];
    ii=ii+1;
    % ==================
    %    Update Lam
    % ==================
    Lam1(1:m,:) = Lam1(1:m,:) + beta*(D1X-p(1:m,:));
    Lam1(m+1:2*m,:) = Lam1(m+1:2*m,:) + beta*(D2X-p(m+1:2*m,:));
    Lam2 = Lam2 + beta*(f-Bn.*w);
    Lam3 = Lam3 + beta*(f-q);
    Lam4 = Lam4 + beta*(v-w);
end
out.sol = f;
out.w=w;
out.itr = ii;
fprintf('Iter: %d, psnrf: %4.2f, rel1: %4.2f,rel2: %4.2f\n',ii,psnrf,rel1,rel2);
% figure,plot(out.fval),title('the history of function values')%%function value
% figure,plot(out.rel1),title('the relative error wrt true image')%%the history of relative errors wrt true image
% figure,plot(out.rel2),title('the relative error wrt true noise')%%the history of relative errors wrt true noise
% figure,imshow(out.sol,[])
expw=sum(w(:))/m/n;
varw=sum((w(:)-expw).^2)/m/n;
fprintf('expw: %4.2f, varw: %4.2f\n',expw,varw);
fprintf('relchgf: %1.5f, relchgw: %1.5f\n',relchg,relchgw);