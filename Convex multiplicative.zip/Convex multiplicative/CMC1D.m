%%% convex variational model of multiplicative noise cleaning, implemented by Xi-Le Zhao(UESTC & HKBU)
function out = CMC1D(Bn,I,N,H,mvw,alpha1,alpha2,opts)
% Suppose the data accuquisition model is given by: Bn= I.*Noise,
% where I is an original image, Noise is
% Gamma noise, and Bn is a noisy observation. To recover
% I from Bn, we solve the following model
% ***    arg min_{f,w} 1/2||w||_2^2+alpha1||z||_1+alpha2 ||p||_2       ***
% ***    st:  H*f-s=z, D*f=p,s=Bn*w where w is 1/n
beta = opts.beta;
[m n] = size(Bn);
[D,Dt]= defDDt;
eigsH = psf2otf(H,[m,n]);
eigsHTH = abs(eigsH).^2;
eigsDTD=abs(psf2otf([1,-1],[m n])).^2 + abs(psf2otf([1;-1],[m n])).^2;
a11=eigsHTH+eigsDTD;
a22=2*ones(m,n);
a12=-conj(eigsH);
a21=-eigsH;
% initi
Lam1 = zeros(2*m,n);
Lam2 = zeros(m,n);
Lam3 = zeros(m,n);
% initi x=[f; s]
f=Bn;
s=zeros(m,n);
w=zeros(m,n);
[D1X,D2X] = D(Bn);
%  history
out.psnr   = [];
out.relchg = [];
out.relf=[];
out.reln=[];
out.relchgw=[];
out.fval=[];
relchg=1;
ii=0;
while relchg > opts.relchg && ii<opts.maxitr
    %%%% Step 1 update y=[p;z;w]
    % ==================
    %  p subproblem
    % ==================
    Z1 = D1X + Lam1(1:m,:)/beta;
    Z2 = D2X + Lam1(m+1:2*m,:)/beta;
    V = Z1.^2 + Z2.^2;
    V = sqrt(V);
    V(V==0) = 1;
    V = max(V - alpha2/beta, 0)./V;
    p(1:m,:) = Z1.*V;
    p(m+1:2*m,:) = Z2.*V;
    % ==================
    %  z subproblem
    % ==================
    z=Mf(f,eigsH)+Lam2/beta-s;
    z=sign(z).*max(0, abs(z) - alpha1/beta);
    % ==================
    %  w subproblem
    % ==================
    wp=w;
    right=mvw*ones(m,n)+Bn.*(beta*s+Lam3);
    w=right./(ones(m,n)+beta*(Bn.^2));
    %%%% Step 2 update [f; s]
    % ==================
    %  f s subproblem
    % ==================
    fp=f;
    b1=fft2(Dt(p(1:m,:),p(m+1:2*m,:))-Dt(Lam1(1:m,:),Lam1(m+1:2*m,:))/beta+MTf(z-Lam2/beta,eigsH));
    b2=fft2(Bn.*w-Lam3/beta-(z-Lam2/beta));
    %%%solve the linear system ax=b by Cramer's Rule
    Det=a11.*a22-a12.*a21;
    f=(b1.*a22-b2.*a21)./Det;
    s=(a11.*b2-a12.*b1)./Det;
    f=real(ifft2(f));
    s=real(ifft2(s));
    [D1X,D2X] = D(f);
    %%%%metric
    psnrf=psnr(f,I);
    out.psnr = [out.psnr;  psnrf ];
    relchg=norm(f - fp,'fro')/norm(f,'fro');
    out.relchg = [out.relchg;relchg];
    out.relchgw=[out.relchgw,norm(w - wp,'fro')/norm(w,'fro')];
    relf=norm(f- I,'fro')/norm(I,'fro'); %relative error wrt true image
    reln=norm(1./w-N,'fro')/norm(N,'fro');%relative error wrt true noise
    out.relf=[out.relf,relf];
    out.reln=[out.reln,reln];
    fval=0.5*(norm(w-mvw*ones(m,n),'fro')).^2+alpha1*sum(sum(abs(z)))+alpha2*sum(sum(sqrt(D1X.^2 + D2X.^2)));
    out.fval=[out.fval,fval];
    ii=ii+1;
    % ==================
    %  Update Lam
    % ==================
    Lam1(1:m,:) = Lam1(1:m,:) + beta*(D1X-p(1:m,:));
    Lam1(m+1:2*m,:) = Lam1(m+1:2*m,:) + beta*(D2X-p(m+1:2*m,:));
    Lam2 = Lam2 + beta*(Mf(f,eigsH)-s-z);
    Lam3 = Lam3 + beta*(s-Bn.*w);
end
out.sol = f;
out.w=w;
out.s=s;
out.z=z;
out.itr = ii;
fprintf('Iter: %d, psnrf: %4.2f, relf: %4.2f,reln: %4.2f\n',ii,psnrf,relf,reln);
% mv=sum(w(:))/m/n;
% var=sum((w(:)-mv).^2)/m/n;
% varw=sum(sum((1./N-mvw).^2))/m/n;
% fprintf('mv: %4.2f, var: %4.2f, mvw: %4.2f, varw: %4.2f\n',mv,var,mvw,varw);

