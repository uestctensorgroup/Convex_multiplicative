function out = Mf(I,eigsH)
out=real(ifft2(eigsH.* fft2(I)));