%%% convex variational model of multiplicative noise cleaning, implemented by Xi-Le Zhao(UESTC & HKBU)
function out=CMC4D(Bn,I,N,H,mvw,alpha,opts)
beta = opts.beta;
[m n]= size(Bn);
T=m*n;%%total number
varw=sum(sum((1./N-mvw).^2))/T;
[D,Dt] = defDDt;
eigsH = psf2otf(H,[m,n]);
eigsHTH = abs(eigsH).^2;
eigsDTD=abs(psf2otf([1,-1],[m n])).^2 + abs(psf2otf([1;-1],[m n])).^2;
a11=eigsHTH +eigsDTD;
a12=-conj(eigsH);
a21=-eigsH;
a22=2*ones(m,n);
S=1./(Bn.^2+ones(m,n));
%initi
Lam1 = zeros(2*m,n);
Lam2 = zeros(m,n);
Lam3 = zeros(m,n);
Lam4 = zeros(m,n);
Lam5 = 0;
%initi
f=Bn;
[D1X,D2X]=D(Bn);
w=zeros(m,n);
u=zeros(m,n);
s=zeros(m,n);
%history
out.psnr =[];
out.relf=[];
out.reln=[];
out.fval=[];
out.relchg =[];
out.relchgw=[];
out.fz=[];
relchg=1;
ii=1;
%% Main loop
while relchg > opts.relchg && ii<opts.maxitr
    %%%% Step 1 update y=[p;z;w]
    % ==================
    %  p subproblem
    % ==================
    Z1 = D1X + Lam1(1:m,:)/beta;
    Z2 = D2X + Lam1(m+1:2*m,:)/beta;
    V = Z1.^2 + Z2.^2;
    V = sqrt(V);
    V(V==0) = 1;
    V = max(V - alpha/beta, 0)./V;
    p(1:m,:) = Z1.*V;
    p(m+1:2*m,:) = Z2.*V;
    % ==================
    %  z subproblem
    % ==================
    z=Mf(f,eigsH)+Lam2/beta-s;
    z=sign(z).*max(0,abs(z)-1/beta);
    % ==================
    %  w subproblem
    % ==================
    wp=w;
    right=u+Lam3/beta+Bn.*(s+Lam4/beta)+(mvw-Lam5/beta)*ones(m,n)/T;
    w=S.*right-S.*sum(sum(S.*right))*ones(m,n)/T^2/(1+sum(S(:))/T^2);   
  %%%% Step 2 update x=[f;s;u]    
    fp=f;
    b2=fft2(Bn.*w-Lam4/beta-z+Lam2/beta);
    b1=fft2(Dt(p(1:m,:),p(m+1:2*m,:))-Dt(Lam1(1:m,:),Lam1(m+1:2*m,:))/beta+MTf(z-Lam2/beta,eigsH));
    %%%solve the linear system ax=b by Cramer's Rule
    det=a11.*a22-a12.*a21;
    f=(b1.*a22-b2.*a12)./det;
    s=(a11.*b2-a21.*b1)./det;
    f=real(ifft2(f));
    s=real(ifft2(s));
    [D1X,D2X]=D(f);
    % ==================
    %  u subproblem
    % ==================
    scale=max(norm(mvw*ones(m,n)+Lam3/beta-w,'fro')-sqrt(T*varw),0)/norm(mvw*ones(m,n)+Lam3/beta-w,'fro');
    u=scale*(mvw*ones(m,n)+Lam3/beta-w)+w-Lam3/beta;
    %%%%metric
    psnrf= psnr(f,I);
    out.psnr=[out.psnr; psnrf];
    relchg=norm(f - fp,'fro')/norm(f,'fro');
    out.relchg=[out.relchg; relchg];
    relchgw=norm(w - wp,'fro')/norm(w,'fro');
    out.relchgw=[out.relchgw,relchgw];
    relf=norm(f- I,'fro')/norm(I,'fro'); %relative error wrt true image
    reln=norm(1./w-N,'fro')/norm(N,'fro');%relative error wrt true noise
    out.relf=[out.relf,relf];
    out.reln=[out.reln,reln];
    fval=sum(sum(abs(Bn.*w-f)))+alpha*sum(sum(sqrt(D1X.^2 + D2X.^2)));
    out.fz=[out.fz,sum(sum(abs(z)))];
    out.fval=[out.fval,fval];
    ii=ii+1;
    % ==================
    %    Update Lam
    % ==================   
    Lam1(1:m,:) = Lam1(1:m,:) + beta*(D1X-p(1:m,:));
    Lam1(m+1:2*m,:) = Lam1(m+1:2*m,:) + beta*(D2X-p(m+1:2*m,:));
    Lam2 = Lam2 + beta*(f-s-z);
    Lam3 = Lam3 + beta*(u-w);
    Lam4 = Lam4 + beta*(s-Bn.*w);
    Lam5 = Lam5+beta*(sum(w(:))/T-mvw);
end
out.sol=f;
out.w=w;
out.z=z;
out.s=s;
out.itr = ii;
fprintf('Iter: %d, psnrf: %4.2f, relf: %4.2f,reln: %4.2f\n',ii,psnrf,relf,reln);
mv=sum(w(:))/m/n;
var=sum((w(:)-mv).^2)/m/n;
fprintf('mv: %4.2f, var: %4.2f, mvw: %4.2f, varw: %4.